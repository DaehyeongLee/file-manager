int main () {
  int value = 0;

  printf("%d", value);
}