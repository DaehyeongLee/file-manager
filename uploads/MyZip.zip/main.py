i = 1
j = 2

print("Hello")